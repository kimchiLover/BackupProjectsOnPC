package com.amma;
import org.springframework.orm.hibernate3.HibernateTemplate;

import java.util.ArrayList;
import java.util.List;

public class UserDetailsDao
{
    HibernateTemplate template;

    public void setTemplate(HibernateTemplate template) {
        this.template = template;
    }

    //method to save employee
    public void saveuser(UserDetails e){
        template.save(e);
    }

    //method to update employee
    public void updateuser(UserDetails e){
        template.update(e);
    }

    //method to delete employee
    public void deleteuser(UserDetails e){
        template.delete(e);
    }

    //method to return one employee of given id
    public UserDetails getById(int id){
        UserDetails e=(UserDetails) template.get(UserDetails.class,id);
        return e;
    }
    //method to return all employees
    public List<UserDetails> getuser(){
        List<UserDetails> list=new ArrayList<UserDetails>();
        return template.loadAll(UserDetails.class);
    }
}